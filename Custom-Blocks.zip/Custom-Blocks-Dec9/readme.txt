=== Custom Blocks Plugin ===
Contributors: GageW.Reed 
Tags: blocks, editor, customization  
Requires at least: 6.0  
Tested up to: 6.5  
Stable tag: 1.0.0  
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
These are my custom blocks for the Gutenberg editor. Includes a newsletter, interactive carosel, comparison blocks, and a testimonial slider for interesting quotes.

== Installation ==
1. Upload the plugin folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Start using the new blocks in the editor

== Changelog ==
= 1.0.0 =
* Initial release with example block and styling

== Frequently Asked Questions ==
= Can I add my own blocks? =
Yes! You can extend the plugin by registering additional blocks in the `blocks/` directory.